//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Package
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const {
    Bot
} = require('grammy');
const {
    Configuration,
    OpenAIApi
} = require("openai");
require('dotenv').config()
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const configuration = new Configuration({
    apiKey: process.env.SECRET_KEY_NEXT,
});
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const bot = new Bot(process.env.SECRET_BOT_KEY);
const openai = new OpenAIApi(configuration);
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bot.on("message", (ctx) => {
    const question = ctx.message.text;
    openai.createCompletion({
        model: "text-davinci-003",
        prompt: question,
        max_tokens: 20,
        temperature: 0.9,
        n: 1,
    }).then(response => {
        console.log(response.data.choices[0].text);
        ctx.reply(response.data.choices[0].text);
    }).catch(err => {
        console.log(err)
    });
});
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.command("start", (ctx) => ctx.reply("Welcome! To Code-180 Tutorial."));
// bot.command("end", (ctx) => ctx.reply("Buy."));
// bot.hears('Hello-180', (ctx) => ctx.reply('Like And Subscribe'));
// bot.hears('Hello', (ctx) => ctx.reply('Like And Subscribe'));
// bot.on('message:text', (ctx) => ctx.reply(`Greeting "${ctx.update.message.text}" is not supported.`))
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.on("message"); // called when any message is received
// bot.on("message:text"); // only text messages
// bot.on("message:photo"); // only photo messages
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.on("message:entities:url"); // messages containing a URL
// bot.on("message:entities:code"); // messages containing a code snippet
// bot.on("edited_message:entities"); // edited messages with any kind of entities
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// bot.on(":text"); // any text messages and any text post of channels
// bot.on("message::url"); // messages with URL in text or caption (photos, etc)
// bot.on("::email"); // messages or channel posts with email in text or caption
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bot.start();